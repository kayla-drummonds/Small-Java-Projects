package cafeApp;

import java.util.Scanner;

public class CafeApp {
	
		public static void main(String[] args) {
			
			double subtotal = 0;
			double salesTax = 0;
			double salesTotal = 0;
			final double SALES_TAX_RATE = .0625;
			
			Product coffee = new Product("Coffee", 3.49, "Delicious hot beverage");
			Product espresso = new Product("Espresso", 3.99, "Delicious hot beverage with lots of caffeine");
			Product cappuccino = new Product("Cappuccino", 4.99, "Delicious hot and creamy beverage");
			
			Scanner s = new Scanner(System.in);
			System.out.println("How many cups of coffee would you like?");
			coffee.setQuantity(s.nextInt());
			
			System.out.println("How many cups of espresso would you like?");		
			espresso.setQuantity(s.nextInt());
			
			System.out.println("How many cups of cappucino would you like?");
			cappuccino.setQuantity(s.nextInt());
			
			System.out.printf("Item: %s, Description: %s, Product Subtotal: %.2f%n", 
					coffee.getName(), coffee.getDescription(), coffee.calculateProductSubtotal());
			System.out.printf("Item: %s, Description: %s, Product Subtotal: %.2f%n", 
					espresso.getName(), espresso.getDescription(), espresso.calculateProductSubtotal());
			System.out.printf("Item: %s, Description: %s, Product Subtotal: %.2f%n", 
					cappuccino.getName(), cappuccino.getDescription(), cappuccino.calculateProductSubtotal());
			
			subtotal = coffee.calculateProductSubtotal() + espresso.calculateProductSubtotal() + cappuccino.calculateProductSubtotal();
			System.out.printf("Purchase Subtotal: %.2f%n", subtotal);
			salesTax = subtotal * SALES_TAX_RATE;
			System.out.printf("Sales Tax: %.2f%n", salesTax);
			salesTotal = subtotal + salesTax;
			System.out.printf("Purchase Total: %.2f%n", salesTotal);
		
			s.close();	
		}

}
