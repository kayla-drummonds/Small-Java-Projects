package cafeApp;

public class Cappucino extends Product {

	protected Boolean peppermint;
	protected Boolean whippedCream;
	
	public Cappucino(String name, Double price, String description) {
		super(name, price, description);
		this.peppermint = false;
		this.whippedCream = false;
	}

	public Boolean getPeppermint() {
		return peppermint;
	}

	public void setPeppermint(Boolean peppermint) {
		this.peppermint = peppermint;
	}

	public Boolean getWhippedCream() {
		return whippedCream;
	}

	public void setWhippedCream(Boolean whippedCream) {
		this.whippedCream = whippedCream;
	}

	public void CappucinoProduct(String name, Double price, String description, Boolean peppermint, Boolean whippedCream) {
		this.name = name;
		this.price = price;
		this.description = description;
	}

	@Override
	public double calculateProductSubtotal() {
		return price * quantity;		
	}

	@Override
	public void addOptions() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printOptions() {
		// TODO Auto-generated method stub
		
	}
	
}
