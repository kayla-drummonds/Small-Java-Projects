package cafeApp;

public class Coffee extends Product {

	protected Boolean sugar;
	protected Boolean milk;
	
	public Coffee(String name, Double price, String description) {
		super(name, price, description);
		this.sugar = false;		
		this.milk = false;
	}
	
	public Boolean getSugar() {
		return sugar;
	}

	public void setSugar(Boolean sugar) {
		this.sugar = sugar;
	}

	public Boolean getMilk() {
		return milk;
	}

	public void setMilk(Boolean milk) {
		this.milk = milk;
	}
	
	public void CoffeeProduct(String name, Double price, String description, Boolean sugar, Boolean milk) {
		this.name = name;
		this.price = price;
		this.description = description;
	}

	@Override
	public double calculateProductSubtotal() {
		return price * quantity;
	}

	@Override
	public void addOptions() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printOptions() {
		// TODO Auto-generated method stub
		
	}
}
