package cafeApp;

public class Espresso extends Product {

	protected boolean extraShot;
	protected boolean macchiato;
	
	public Espresso(String name, Double price, String description) {
		super(name, price, description);
		this.extraShot = false;
		this.macchiato = false;
	}

	public boolean isExtraShot() {
		return extraShot;
	}

	public void setExtraShot(boolean extraShot) {
		this.extraShot = extraShot;
	}

	public boolean isMacchiato() {
		return macchiato;
	}

	public void setMacchiato(boolean macchiato) {
		this.macchiato = macchiato;
	}

	public void EspressoProduct (String name, Double price, String description, Boolean extraShot, Boolean macchiato) {
		this.name = name;
		this.price = price;
		this.description = description;
	}

	@Override
	public double calculateProductSubtotal() {
		return price * quantity;
	}

	@Override
	public void addOptions() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printOptions() {
		// TODO Auto-generated method stub
		
	}

}
