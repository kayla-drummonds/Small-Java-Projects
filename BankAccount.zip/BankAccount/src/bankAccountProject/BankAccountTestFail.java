package bankAccountProject;

import static org.junit.Assert.fail;

import org.junit.Test;

public class BankAccountTestFail {
	
	@Test
	public void deposit() throws Exception {
		fail("This test has yet to be implemented");
	}
	
	@Test
	public void withdraw() throws Exception {
		fail("This test has yet to be implemented");
	}
	
	@Test
	public void getBalance() throws Exception {
		fail("This test has yet to be implemented");
	}


}
